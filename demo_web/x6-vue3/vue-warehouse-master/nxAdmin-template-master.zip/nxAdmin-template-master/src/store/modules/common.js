import website from '@/const/website'
const common = {

  state: {
    website: website
  },
  actions: {
  },
  mutations: {

  }
}
export default common
