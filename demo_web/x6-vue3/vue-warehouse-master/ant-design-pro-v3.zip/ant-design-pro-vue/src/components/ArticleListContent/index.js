import ArticleListContent from './ArticleListContent'

export default ArticleListContent
